var strings = new Array();
strings['cancel'] = '取消';
strings['accept'] = '确定';
strings['manual'] = '手册';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';