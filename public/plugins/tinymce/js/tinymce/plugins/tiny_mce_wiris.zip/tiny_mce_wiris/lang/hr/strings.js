var strings = new Array();
strings['cancel'] = 'Poništi';
strings['accept'] = 'U redu';
strings['manual'] = 'Priručnik';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';