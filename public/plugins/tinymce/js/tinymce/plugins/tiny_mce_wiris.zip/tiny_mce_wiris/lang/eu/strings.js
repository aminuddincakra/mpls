var strings = new Array();
strings['cancel'] = 'Ezeztatu';
strings['accept'] = 'Onartu';
strings['manual'] = 'Gida';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';