var strings = new Array();
strings['cancel'] = 'Cancel·lar';
strings['accept'] = 'Acceptar';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';