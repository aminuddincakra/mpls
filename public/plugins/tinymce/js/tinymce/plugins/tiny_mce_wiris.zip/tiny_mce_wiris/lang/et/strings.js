var strings = new Array();
strings['cancel'] = 'Loobu';
strings['accept'] = 'OK';
strings['manual'] = 'Käsiraamat';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';