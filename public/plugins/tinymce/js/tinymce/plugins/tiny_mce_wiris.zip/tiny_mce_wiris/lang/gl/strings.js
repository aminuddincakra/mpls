var strings = new Array();
strings['cancel'] = 'Cancelar';
strings['accept'] = 'Aceptar';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';